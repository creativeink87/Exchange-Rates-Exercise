# Exchange-Rates-Exercise
Web App Test

My goal during creating this app was to make it as clear as possible how to use it as well as functional.
Focusing on not only a clear UI but also the UX behind it.
I have kept the UI simple with easy to read fonts and strong use of a simplified color pallete, and enhancing call to actions with green to make them more prominent to the user.

To use the app simpy open the index.html file.

For future updates I would look to do the bonus parts of the brief and provide the past rates.
I would also introduce some media queries to improve the apps scalability.
I would also look to introduce Iconography to enhance the userbility.
